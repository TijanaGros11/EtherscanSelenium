package EtherscanTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import EtherscanPage.BasePageEtherscan;
import EtherscanPage.HomePageEtherscan;
import EtherscanPage.LoginPageEtherscan;
import EtherscanPage.NavBarPageEtherscan;
import EtherscanPage.RegistrationPageEtherscan;

public class EtherscanScenario {
	private WebDriver driver;
	private BasePageEtherscan basePageEtherscan;
	private HomePageEtherscan homePageEtherscan;
	private LoginPageEtherscan loginPageEtherscan;
	private NavBarPageEtherscan navBarPageEtherscan;
	private RegistrationPageEtherscan registrationPageEtherscan;

	@BeforeSuite
	public void initalize() {

		System.setProperty("webdriver.chrome.driver", "chromedriver");
		driver = new ChromeDriver();

		basePageEtherscan = new BasePageEtherscan(driver);
		homePageEtherscan = new HomePageEtherscan(driver);
		loginPageEtherscan = new LoginPageEtherscan(driver);
		navBarPageEtherscan = new NavBarPageEtherscan(driver);
		registrationPageEtherscan = new RegistrationPageEtherscan(driver);

		driver.manage().window().maximize();

		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
	}

	@BeforeMethod
	public void goToRegistrationPage() {
		driver.navigate().to("https://etherscan.io/register");

		assertTrue(basePageEtherscan.presentsOfTitle("Etherscan Registration Page"));
	}

	@Test()
	public void testRegistarEmptyForm() throws InterruptedException {

		basePageEtherscan.acceptCookie();

		registrationPageEtherscan.clickCreateAccountButton();

		assertEquals(registrationPageEtherscan.getUsernameInputError(), "Please enter Username.");
		assertEquals(registrationPageEtherscan.getEmailInputError(), "Please enter a valid email address.");
		assertEquals(registrationPageEtherscan.getConfirmEmailInputError(), "Please re-enter your email address.");
		assertEquals(registrationPageEtherscan.getPasswordInputError(), "Please enter Password.");
		assertEquals(registrationPageEtherscan.getConfirmPasswordInputError(),
				"Your password must be at least 8 characters long.");

	}

	@Test(priority = 1)
	public void testRegistarInvalidUsername() {

		registrationPageEtherscan.setRegistrationUsername("tija");
		assertEquals(registrationPageEtherscan.getUsernameInputError(), "Please enter at least 5 characters.");

		registrationPageEtherscan.setRegistrationUsername("tija=");
		assertEquals(registrationPageEtherscan.getUsernameInputError(), "Only alphanumeric characters allowed.");
	}

	@Test(priority = 2)
	public void testRegistarInvalidEmail() {

		registrationPageEtherscan.setRegistrationEmail("tija");
		assertEquals(registrationPageEtherscan.getEmailInputError(), "Please enter a valid email address.");

		registrationPageEtherscan.setRegistrationEmail("tija@");
		assertEquals(registrationPageEtherscan.getEmailInputError(), "Please enter a valid email address.");

		registrationPageEtherscan.setRegistrationEmail("tija@gmail");
		registrationPageEtherscan.setRegistrationConfirmEmail("tija");
		assertEquals(registrationPageEtherscan.getConfirmEmailInputError(), "Please re-enter your email address.");

		registrationPageEtherscan.setRegistrationConfirmEmail("tija@g");
		assertEquals(registrationPageEtherscan.getConfirmEmailInputError(), "Email address does not match.");
	}

	@Test(priority = 3)
	public void testRegistarInvalidPassword() {

		registrationPageEtherscan.setRegistrationPassword("tija");
		assertEquals(registrationPageEtherscan.getPasswordInputError(),
				"Your password must be at least 8 characters long.");

		registrationPageEtherscan.setRegistrationPassword("MojpasOri1.");
		registrationPageEtherscan.setRegistrationConfirmPassword("tija");
		assertEquals(registrationPageEtherscan.getConfirmPasswordInputError(),
				"Your password must be at least 8 characters long.");

		registrationPageEtherscan.setRegistrationConfirmPassword("tijana123");
		assertEquals(registrationPageEtherscan.getConfirmPasswordInputError(),
				"Password does not match, please check again.");
	}

	@Test(priority = 4)
	public void testRegistarSuccess() throws InterruptedException {

		assertTrue(basePageEtherscan.presentsOfTitle("Etherscan Registration Page"));

		registrationPageEtherscan.setRegistrationUsername("tijanagros11");
		registrationPageEtherscan.setRegistrationEmail("grostijana@gmail.com");
		registrationPageEtherscan.setRegistrationConfirmEmail("grostijana@gmail.com");
		registrationPageEtherscan.setRegistrationPassword("MojpasOri1.");
		registrationPageEtherscan.setRegistrationConfirmPassword("MojpasOri1.");
		registrationPageEtherscan.clickTermsandConditionsButton();

		// TODO: resolve captcha

		registrationPageEtherscan.clickCreateAccountButton();

		String msgString = homePageEtherscan.getRegistrationMessage();
		assertEquals(msgString, "Your account registration has been submitted and is pending email verification.");

	}

	@AfterSuite
	public void quitDriver() {

		driver.quit();

	}
}
