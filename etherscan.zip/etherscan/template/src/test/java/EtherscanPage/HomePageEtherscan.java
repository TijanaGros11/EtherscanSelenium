package EtherscanPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePageEtherscan {
	private WebDriver driver;

	public HomePageEtherscan(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public String getRegistrationMessage() {
		WebElement registrationMessageDiv = this.driver.findElement(By.xpath("//div[@class='alert alert-info']"));
		return registrationMessageDiv.getText();
	}

	public String getLoginMessage() {
		WebElement loginMessageDiv = this.driver.findElement(By.xpath("//div[@class='alert alert-danger']"));
		return loginMessageDiv.getText();
	}

}
