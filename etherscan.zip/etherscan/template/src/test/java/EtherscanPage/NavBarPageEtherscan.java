package EtherscanPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NavBarPageEtherscan {
	private WebDriver driver;

	public NavBarPageEtherscan(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void clickSingInLink() {
		WebElement el = new WebDriverWait(driver, 10).until(
				ExpectedConditions.elementToBeClickable(By.cssSelector("[class='link-dark d-block d-lg-none']")));
		el.click();
	}

	public void clickRegistrationUsernameLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_txtUserName")));
		el.click();
	}

	public void clickRegistrationEmailLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_txtEmail")));
		el.click();
	}

	public void clickRegistrationConfirmEmailLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_txtConfirmEmail")));
		el.click();
	}

	public void clickRegistrationPasswordLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_txtPassword")));
		el.click();
	}

	public void clickRegistrationConfirmPasswordLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_txtPassword2")));
		el.click();
	}

	public void clickTermsandConditionsButtonLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[type='checkbox']")));
		el.click();
	}

	public void clickEtherscanNewsletterButtonLink() {
		WebElement el = new WebDriverWait(driver, 10).until(
				ExpectedConditions.elementToBeClickable(By.cssSelector("ContentPlaceHolder1_SubscribeNewsletter")));
		el.click();
	}

	public void clickImNotArobotButtonLink() {
		WebElement el = new WebDriverWait(driver, 10).until(
				ExpectedConditions.elementToBeClickable(By.cssSelector("[class='recaptcha-checkbox-checkmark']")));
		el.click();
	}

	public void clickCreateAccountButtonLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.cssSelector("ContentPlaceHolder1_btnRegister")));
		el.click();
	}

	public void clickLogintButtonLink() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.elementToBeClickable(By.id("ContentPlaceHolder1_btnLogin")));
		el.click();
	}

}
