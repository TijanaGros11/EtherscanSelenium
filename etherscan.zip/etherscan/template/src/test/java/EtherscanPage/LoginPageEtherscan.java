package EtherscanPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPageEtherscan {
	private WebDriver driver;

	public LoginPageEtherscan(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getUsername() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtUserName")));
		return el;
	}

	public void setUsername(String value) {
		WebElement usernameElement = this.getUsername();
		usernameElement.clear();
		usernameElement.sendKeys(value);
	}

	public WebElement getPassword() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtPassword")));
		return el;
	}

	public void setPassword(String value) {
		WebElement passwordElement = this.getPassword();
		passwordElement.clear();
		passwordElement.sendKeys(value);
	}

	public void clickRememberAutoLoginButton() {
		driver.findElement(By.id("ContentPlaceHolder1_chkRemember")).click();
	}

	public void clickImNotArobotButton() {
		driver.findElement(By.cssSelector("[class='recaptcha-checkbox-border']")).click();
	}

	public void clickLoginButton() {
		driver.findElement(By.id("ContentPlaceHolder1_btnLogin")).click();
	}

	public void signIn(String username, String password) {
		this.setUsername(username);
		this.setPassword(password);
		this.clickLoginButton();
	}

}
