package EtherscanPage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPageEtherscan {
	private WebDriver driver;

	public RegistrationPageEtherscan(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public WebElement getRegistrationUsername() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtUserName")));
		return el;
	}

	public WebElement getRegistrationEmail() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtEmail")));
		return el;
	}

	public WebElement getRegistrationConfirmEmail() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtConfirmEmail")));
		return el;
	}

	public WebElement getRegistrationPassword() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtPassword")));
		return el;
	}

	public WebElement getRegistrationConfirmPassword() {
		WebElement el = new WebDriverWait(driver, 10)
				.until(ExpectedConditions.visibilityOfElementLocated(By.id("ContentPlaceHolder1_txtPassword2")));
		return el;
	}

	public void setRegistrationUsername(String value) {
		WebElement el = this.getRegistrationUsername();
		el.clear();
		el.sendKeys(value);
	}

	public void setRegistrationEmail(String value) {
		WebElement el = this.getRegistrationEmail();
		el.clear();
		el.sendKeys(value);
	}

	public void setRegistrationConfirmEmail(String value) {
		WebElement el = this.getRegistrationConfirmEmail();
		el.clear();
		el.sendKeys(value);
	}

	public void setRegistrationPassword(String value) {
		WebElement el = this.getRegistrationPassword();
		el.clear();
		el.sendKeys(value);
	}

	public void setRegistrationConfirmPassword(String value) {
		WebElement el = this.getRegistrationConfirmPassword();
		el.clear();
		el.sendKeys(value);
	}

	public void clickTermsandConditionsButton() {
		driver.findElement(By.id("ContentPlaceHolder1_MyCheckBox")).click();
	}

	public void clickEtherscanNewsletterButton() {
		driver.findElement(By.id("ContentPlaceHolder1_SubscribeNewsletter")).click();
	}

	public void clickImNotArobotButton() {
		driver.findElement(By.id("recaptcha-anchor")).click();
	}

	public void clickCreateAccountButton() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		//Locating element by link text and store in variable "Element"        		
        WebElement el = driver.findElement(By.id("ContentPlaceHolder1_btnRegister"));

        // Scrolling down the page 		
        js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
        
        Thread.sleep(1000);
        
		el.click();
	}

	public String getUsernameInputError() {
		WebElement el = driver.findElement(By.id("ContentPlaceHolder1_txtUserName-error"));
		return el.getText();
	}
	
	public String getEmailInputError() {
		WebElement el = driver.findElement(By.id("ContentPlaceHolder1_txtEmail-error"));
		return el.getText();
	}
	
	public String getConfirmEmailInputError() {
		WebElement el = driver.findElement(By.id("ContentPlaceHolder1_txtConfirmEmail-error"));
		return el.getText();
	}
	
	public String getPasswordInputError() {
		WebElement el = driver.findElement(By.id("ContentPlaceHolder1_txtPassword-error"));
		return el.getText();
	}
	
	public String getConfirmPasswordInputError() {
		WebElement el = driver.findElement(By.id("ContentPlaceHolder1_txtPassword2-error"));
		return el.getText();
	}
}
