package EtherscanPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePageEtherscan {

	private WebDriver driver;

	public BasePageEtherscan(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public boolean presentsOfTitle(String title) {
		boolean isPresent = new WebDriverWait(driver, 10).until(ExpectedConditions.titleIs(title));
		return isPresent;

	}

	public boolean checkUrl(String url) {
		return new WebDriverWait(driver, 10).until(ExpectedConditions.urlToBe(url));
	}

	public WebElement getModalDialog() {
		return new WebDriverWait(driver, 10)
				.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("ContentPlaceHolder1_maindiv")));
	}

	public void acceptCookie() {
		new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(By.id("btnCookie"))).click();
	}
}
